##TinyFrontend

-----

> WyTiny Begins at 24/05/2015 

-----

####About TinyMint
TinyMint is an online webpage builder.
Using the provided templates and graphical Interfaces, users can easily design a webpage with custom pictures, articles and multimedias.
It's inspired by MS Sway and the initial UI of TinyMint is similar to Sway, yet in later versions TinyMint would be equiped with more auxiliary functions and tools to bring a brilliant experience to users.

####On Maintains...

-----

##### 6.6 Dashboard Frontend version 1

##### 6.25 Editor Board version 1.0